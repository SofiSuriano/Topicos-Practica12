# CRUDS DE CATALOGOS
## Practica 12-CRUDs de catálogos

Pasos a seguir: 

💜Paso1.Crear la BD

💜Paso2.Generar el Entorno virtual

💜Paso3.Habilitar el entorno virtual



Podrás encontrarlo aquí [Cruds de catalogos](https://github.com/SofiSuriano/Topicos-Practica12).


### Tecnologías utilizadas

* Python

## Captura del catalogo de clientes

![Captura del catalogo de clientes](/fotos/catalogoclientes.jpeg)
